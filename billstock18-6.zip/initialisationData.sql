insert into bill_ville(designation)
  VALUE('Likasi')('Lubumbashi')('Kipushi')('Kalemie')('Moba ')('Kakanda')