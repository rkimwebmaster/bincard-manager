<?php

namespace App\Form;

use App\Entity\LigneControle;
use App\Entity\ProduitSite;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

class LigneControleType extends AbstractType
{
    private $tokenStorage;
    public function __construct(TokenStorageInterface $tokenStorage)
    {
      $this->tokenStorage=$tokenStorage;        

    }
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $site=$this->tokenStorage->getToken()->getUser()->getSiteActif();
        $builder
        // ->add('solde')
        // ->add('produitSite')  
            ->add('produitSite', EntityType::class , [
              'class' => ProduitSite::class,
              'query_builder' => function ( EntityRepository $er ) use ($site) {
          return $er->createQueryBuilder('c')
            ->where('c.site = :val')
            ->setParameter('val', $site)
            ->orderBy('c.id', 'ASC');
          },
      ])             ->add('quantitePhysique')
            ->add('observation')
           // ->add('controle')
           // ->add('ligneBillcard')
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => LigneControle::class,
        ]);
    }
}
