<?php

namespace App\Controller;

use App\Entity\LigneSortie;
use App\Entity\ProduitSite;
use App\Entity\Site;
use App\Entity\Sortie;
use App\Form\SortieDamageType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;


/**
 *@IsGranted("IS_AUTHENTICATED_FULLY")
 * @Route("/damage")
 */
class DamageController extends AbstractController
{
    /**
     * @Route("/damage", name="damage")
     */
    public function index(): Response
    {
        return $this->render('damage/index.html.twig', [
            'controller_name' => 'DamageController',
        ]);
    }


    /**
     * @Route("/{id}/nouveauDamage", name="nouveau_damage")
     */
    public function nouveauDamage(ProduitSite $produitSite, Request $request)
    {

        //seuls les site simple qui ne sont pas warehouse peuvent effectués les sorties 

        $siteActif = $this->getUser()->getSiteActif();

        //verifier s'il existe au moin un site et un produits dans le site 
        $sites = $this->getDoctrine()->getManager()->getRepository(Site::class)->findAll();

        if (!$sites) {
            $this->addFlash('warning', 'Aucun site dans la base. Enregistrer d\'abord un site . ');

            return $this->redirectToRoute('sortie_index');
        }


        $sortie = new Sortie();
        $sortie->setUser($this->getUser());
        $sortie->setIsDamage(true);
        $ligneSortie = new LigneSortie();
        $ligneSortie->setProduitSite($produitSite);
        $sortie->addLigneSorty($ligneSortie);
        $form = $this->createForm(SortieDamageType::class, $sortie);
        $form->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid()) {

            // dd('salut');

            //affecter le user et le site emetteur 
            $user = $this->getUser();
            $site = $user->getSiteActif();
            $sortie->setUser($user);
            $sortie->setSiteEnvoie($site);
            //verifier que la sortie comprend des lignes sorties 
            $ligneSorties = $sortie->getLigneSorties();
            if (sizeof($ligneSorties) == 0) {
                $this->addFlash('warning', 'Vous ne pouvez enregistré une sortie sans détail.');

                return $this->redirectToRoute('sortie_index');
            }            
            //verifier que les doublons sur les lignes 
            // $tableau = array();
            // foreach ($ligneSorties as $ligneSortie1) {
            //    $tableau[] = $ligneSortie1->getLigneSortieTransfert()->getProduitSite()->getId();
            // }
            // $array_unique=array_unique($tableau);

            //if($array_unique!=$tableau){
            //    $this->addFlash('warning', 'Vous ne pouvez enregistré deux fois le même produit.');

            //   return $this->redirectToRoute('sortie_index');           
            //}


            //verifier que les quantités sorties sont inferieur à celle en stock 
            $entityManager = $this->getDoctrine()->getManager();

            $quantiteProduit = 0;
            foreach ($ligneSorties as $ligneSortie) {
                $produitSite = $ligneSortie->getProduitSite();
                $produit=$produitSite->getProduit();

                $quantiteProduit =  $produitSite->getQuantite();
                $quantiteSortie = $ligneSortie->getQuantite();
                if ($quantiteProduit < $quantiteSortie) {
                    $this->addFlash('warning', 'La quantité du produit ' . $produitSite . ' est inférieur à la sortie.');

                    return $this->redirectToRoute('sortie_index');
                }
                $produitSite->setQuantite($quantiteProduit - $quantiteSortie);
                $produit->setQuantite($produit->getQuantite() - $quantiteSortie);
                $entityManager->persist($produit);
                $entityManager->persist($produitSite);
            }

            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($sortie);
            $entityManager->flush();
            $this->addFlash('success', 'Operation réussie.');

            return $this->redirectToRoute('sortie_index');
        }

        return $this->render('sortie/newDamage.html.twig', [
            'sortie' => $sortie,
            'form' => $form->createView(),
        ]);
    }

        /**
     * @Route("/{id}/editDamage", name="sortie_damage_edit", methods={"GET","POST"})
     */
    public function editDamage(Request $request, Sortie $sortie): Response
    {
        $ligneSorties=$sortie->getLigneSorties();
        $uniqueLigneSortie=$ligneSorties[0];
        $produit=$uniqueLigneSortie->getProduitSite();

        $form = $this->createForm(SortieDamageType::class, $sortie, [
            'action' => $this->generateUrl('nouveau_damage', ['id' => $produit->getId()]),
            'method' => 'POST',
        ]);
        $form->handleRequest($request);
        //cette methode ne sera jamais appellée 

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('sortie_index');
        }
        ///
        $entityManager = $this->getDoctrine()->getManager();
        //mettre a jour le produit site 
        $produitSite=$uniqueLigneSortie->getProduitSite();
        $quantiteDamage=$uniqueLigneSortie->getQuantite();
        $produitSite->setQuantite($produitSite->getQuantite()+$quantiteDamage);

        $entityManager->persist($produitSite);
        $entityManager->remove($sortie);
        $entityManager->flush();
        $this->addFlash('warning', 'la sortie damage a été temporairement supprimé. Veuillez confirmer après modification pour rétablissement ');


        return $this->render('sortie/newDamage.html.twig', [
            'sortie' => $sortie,
            'form' => $form->createView(),
        ]);
    }

}
