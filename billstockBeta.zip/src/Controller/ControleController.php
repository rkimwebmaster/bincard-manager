<?php

namespace App\Controller;

use App\Entity\Controle;
use App\Entity\Entree;
use App\Entity\LigneEntree;
use App\Entity\LigneSortie;
use App\Entity\Sortie;
use App\Form\ControleType;
use App\Repository\ControleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;


/**
 *@IsGranted("IS_AUTHENTICATED_FULLY")
 * @Route("/controle")
 */
class ControleController extends AbstractController
{

    /**
     * @Route("/", name="controle_index", methods={"GET"})
     */
    public function index(ControleRepository $controleRepository): Response
    {
        $siteActif=$this->getUser()->getSiteActif();
        return $this->render('controle/index.html.twig', [
            'controles' => $controleRepository->findBy(['site'=>$siteActif], ['date'=>'DESC']),
        ]);
    }

    /**
     * @Route("/new", name="controle_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $user = $this->getUser();
        $site = $user->getSiteActif();
        $controle = new Controle();
        $controle->setSite($site);
        $controle->setUser($user);
        $form = $this->createForm(ControleType::class, $controle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

         //   verifier que les doublons sur les lignes 
         $ligneControles=$controle->getLigneControles();
            $tableau = array();
            foreach ($ligneControles as $ligne1) {
               $tableau[] = $ligne1->getProduitSite()->getId();
            }
            $array_unique=array_unique($tableau);

            if($array_unique!=$tableau){
               $this->addFlash('danger', 'Vous ne pouvez controler/noter deux fois le même produit.');

              return $this->redirectToRoute('controle_index');           
            }
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($controle);
            $entityManager->flush();
            $this->addFlash('success', 'Opération réussie. ');

            return $this->redirectToRoute('controle_index');
        }

        return $this->render('controle/new.html.twig', [
            'controle' => $controle,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="controle_show", methods={"GET"})
     */
    public function show(Controle $controle): Response
    {
        return $this->render('controle/show.html.twig', [
            'controle' => $controle,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="controle_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Controle $controle): Response
    {
        $form = $this->createForm(ControleType::class, $controle);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
                     //   verifier que les doublons sur les lignes 
         $ligneControles=$controle->getLigneControles();
         $tableau = array();
         foreach ($ligneControles as $ligne1) {
            $tableau[] = $ligne1->getProduitSite()->getId();
         }
         $array_unique=array_unique($tableau);

         if($array_unique!=$tableau){
            $this->addFlash('danger', 'Vous ne pouvez controler/noter deux fois le même produit.');

           return $this->redirectToRoute('controle_index');           
         }

         //fin ckeck doublon 
            $this->getDoctrine()->getManager()->flush();
            $this->addFlash('success', 'Opération réussie. ');

            return $this->redirectToRoute('controle_index');
        }

        return $this->render('controle/edit.html.twig', [
            'controle' => $controle,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("valider/{id}/valider", name="controle_valider", methods={"GET","POST"})
     */
    public function valider(Request $request, Controle $controle): Response
    {
//        exit(var_dump('teston'));
        $user=$this->getUser();
        $siteActif=$user->getSiteActif();

        $controle->setIsValidee(true);
        // exit(var_dump('jambo'));
        $entityManager = $this->getDoctrine()->getManager();

        $ligneControles=$controle->getLigneControles();
        foreach($ligneControles as $ligne){
            $produitSite=$ligne->getProduitSite();
            $produit=$produitSite->getProduit();
            $manquant=$ligne->getManquant();
            $surplus=$ligne->getSurplus();
           // $ligne->updateLigneBillcard();
            
            if($ligne->checkManquantSurplus()==-1){
            //créer sortie speciale 
            $sortieSpeciale=new Sortie(null);
            $sortieSpeciale->setIsSortieSpeciale(true);
            $sortieSpeciale->setUser($user);
            $sortieSpeciale->setSiteEnvoie($siteActif);
            $ligneSortie=new LigneSortie();
            $ligneSortie->setProduitSite($produitSite);
            $ligneSortie->setQuantite($manquant);
            $sortieSpeciale->addLigneSorty($ligneSortie);
            $entityManager->persist($sortieSpeciale);

            } elseif($ligne->checkManquantSurplus()== 1){
            //créer entree speciale 
            $entreeSpeciale=new Entree(null,$siteActif);
            $entreeSpeciale->setIsEntreeSpeciale(true);
            $entreeSpeciale->setUser($user);
            $ligneEntree=new LigneEntree();
            $ligneEntree->setProduitSite($produitSite);
            $ligneEntree->setProduit($produit);
            $ligneEntree->setQuantite($surplus);
            $entreeSpeciale->addLigneEntree($ligneEntree);
            //dd($entreeSpeciale->getIsEntreeSpeciale());
            $entityManager->persist($entreeSpeciale);

            }
        }

        $entityManager->persist($controle);
        $entityManager->flush();
        $this->addFlash('success', 'Opération réussie. ');

        return $this->redirectToRoute('controle_index');
    }

    /**
     * @Route("/{id}", name="controle_delete", methods={"DELETE"})
     */
    public function delete(Request $request, Controle $controle): Response
    {
        if ($this->isCsrfTokenValid('delete' . $controle->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($controle);
            $entityManager->flush();
            $this->addFlash('success', 'Opération réussie. ');

        }

        return $this->redirectToRoute('controle_index');
    }
}
